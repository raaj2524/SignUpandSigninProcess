# Assignment
ASP MVC Register new user and send verification to email. Activate the account via email link and allow to Login.
